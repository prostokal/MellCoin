// Tokenomica
document.querySelectorAll('.tokenomika__item-percent').forEach((item, i) => {
    document.querySelectorAll('.tokenomika__item-slider span')[i].style.width = item.innerHTML;
});

// Hamburger
const menu = document.querySelector('.menu');

document.querySelector('.hamburger').addEventListener('click', () => {
    menu.classList.add('active');
});

document.querySelector('.menu__close').addEventListener('click', () => {
    menu.classList.remove('active');
});